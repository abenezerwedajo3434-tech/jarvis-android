package com.jarvis.ai

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat

class VoiceService : Service() {
    override fun onCreate() { super.onCreate();
        val channel = NotificationChannel("jarvis_voice", "JARVIS Voice", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        val n = NotificationCompat.Builder(this, "jarvis_voice").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JARVIS is ready").setContentText("Voice mode is active").setOngoing(true).build()
        startForeground(7, n)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_NOT_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
}

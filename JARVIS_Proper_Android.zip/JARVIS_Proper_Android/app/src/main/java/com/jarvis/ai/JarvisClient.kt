package com.jarvis.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

class JarvisClient(private val baseUrl: String) {
    private val http = OkHttpClient()
    suspend fun ask(message: String, memory: String): String = withContext(Dispatchers.IO) {
        if (baseUrl.contains("YOUR-BACKEND")) return@withContext "Backend not configured. Open Settings and enter your JARVIS backend URL."
        val body = JSONObject().put("message", message).put("memory", memory).toString()
            .toRequestBody("application/json".toMediaType())
        val req = Request.Builder().url(baseUrl.trimEnd('/') + "/jarvis").post(body).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) return@withContext "JARVIS backend error: HTTP ${r.code}"
            val text = r.body?.string().orEmpty()
            runCatching { JSONObject(text).optString("reply") }.getOrElse { text }
        }
    }
}

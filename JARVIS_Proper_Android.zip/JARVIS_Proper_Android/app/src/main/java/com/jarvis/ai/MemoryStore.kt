package com.jarvis.ai

import android.content.Context

class MemoryStore(context: Context) {
    private val p = context.getSharedPreferences("jarvis_memory", Context.MODE_PRIVATE)
    fun add(text: String) { val old = p.getString("items", "").orEmpty(); p.edit().putString("items", (old + "\n" + text).takeLast(8000)).apply() }
    fun all(): String = p.getString("items", "").orEmpty()
    fun clear() = p.edit().clear().apply()
}

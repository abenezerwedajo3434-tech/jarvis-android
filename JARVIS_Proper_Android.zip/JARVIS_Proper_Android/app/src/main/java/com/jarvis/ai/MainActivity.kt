package com.jarvis.ai

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.view.*
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import java.util.*

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var chat: TextView; private lateinit var input: EditText; private lateinit var tts: TextToSpeech
    private lateinit var memory: MemoryStore; private lateinit var client: JarvisClient
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var recognizer: SpeechRecognizer? = null
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    override fun onCreate(b: Bundle?) { super.onCreate(b)
        memory = MemoryStore(this); client = JarvisClient(prefs.getString("backend", "https://YOUR-BACKEND.example.com")!!); tts = TextToSpeech(this, this)
        buildUi(); requestPermissionsIfNeeded()
    }
    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,28,28,20); setBackgroundColor(0xFF05070A.toInt()) }
        val title = TextView(this).apply { text="J.A.R.V.I.S"; textSize=30f; setTextColor(0xFF66E6FF.toInt()); gravity=Gravity.CENTER; setPadding(0,10,0,10) }
        val status = TextView(this).apply { text="ONLINE • VOICE READY"; textSize=12f; setTextColor(0xFF8CA6B0.toInt()); gravity=Gravity.CENTER }
        chat = TextView(this).apply { text="JARVIS: Systems initialized. How may I assist?\n\n"; textSize=17f; setTextColor(0xFFEAFBFF.toInt()); setPadding(18,18,18,18) }
        val scroll = ScrollView(this).apply { addView(chat); layoutParams=LinearLayout.LayoutParams(-1,0,1f) }
        input = EditText(this).apply { hint="Speak or type a command…"; setTextColor(0xFFEAFBFF.toInt()); setHintTextColor(0xFF6F8188.toInt()); setSingleLine(false) }
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val send=Button(this).apply { text="SEND"; setOnClickListener{sendMessage()} }
        val mic=Button(this).apply { text="🎙"; setOnClickListener{listen()} }
        val wake=Button(this).apply { text="WAKE"; setOnClickListener{startVoiceMode()} }
        row.addView(mic,LinearLayout.LayoutParams(0,60,1f)); row.addView(send,LinearLayout.LayoutParams(0,60,1f)); row.addView(wake,LinearLayout.LayoutParams(0,60,1f))
        val settings=Button(this).apply { text="Backend settings"; setOnClickListener{configureBackend()} }
        root.addView(title); root.addView(status); root.addView(scroll); root.addView(input,LinearLayout.LayoutParams(-1,120)); root.addView(row); root.addView(settings)
        setContentView(root)
    }
    private fun append(s:String){ chat.append("\n$s\n"); }
    private fun sendMessage(){ val q=input.text.toString().trim(); if(q.isEmpty())return; input.setText(""); append("YOU: $q");
        when { q.equals("open youtube",true)->open("https://youtube.com"); q.equals("open google",true)->open("https://google.com"); q.startsWith("remember ",true)->{memory.add(q.substring(9)); append("JARVIS: Memory stored.")}; q.equals("what do you remember",true)->append("JARVIS: ${memory.all().ifBlank{"Nothing yet."}}"); else->scope.launch{append("JARVIS: Thinking…"); val a=client.ask(q,memory.all()); append("JARVIS: $a"); speak(a)} }
    }
    private fun open(url:String){startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))}
    private fun listen(){ if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissionsIfNeeded();return};
        recognizer?.destroy(); recognizer=SpeechRecognizer.createSpeechRecognizer(this).also{ r-> r.setRecognitionListener(object:RecognitionListener{
            override fun onResults(x:Bundle){input.setText(x.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty());sendMessage()}
            override fun onError(e:Int){append("JARVIS: Voice error $e")}; override fun onReadyForSpeech(p:Bundle?){}; override fun onBeginningOfSpeech(){}; override fun onRmsChanged(v:Float){}; override fun onBufferReceived(b:ByteArray?){}; override fun onEndOfSpeech(){}; override fun onPartialResults(b:Bundle?){}; override fun onEvent(t:Int,b:Bundle?){}}); r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)}) }
    }
    private fun startVoiceMode(){ if(Build.VERSION.SDK_INT>=26) ContextCompat.startForegroundService(this,Intent(this,VoiceService::class.java)); append("JARVIS: Voice mode started. Use the microphone button to speak.") }
    private fun configureBackend(){ val e=EditText(this).apply{setText(prefs.getString("backend","https://YOUR-BACKEND.example.com")); hint="https://your-server.example.com"}; AlertDialog.Builder(this).setTitle("JARVIS backend").setMessage("Use a server you control. Do not put your OpenAI API key inside the APK.").setView(e).setPositiveButton("Save"){_,_->prefs.edit().putString("backend",e.text.toString()).apply(); client=JarvisClient(e.text.toString());append("JARVIS: Backend updated.")}.setNegativeButton("Cancel",null).show() }
    private fun requestPermissionsIfNeeded(){ val p=mutableListOf<String>(); if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.RECORD_AUDIO); if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.POST_NOTIFICATIONS); if(p.isNotEmpty())ActivityCompat.requestPermissions(this,p.toTypedArray(),55) }
    override fun onInit(status:Int){ if(status==TextToSpeech.SUCCESS)tts.language=Locale.US }
    private fun speak(s:String){tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"jarvis")}
    override fun onDestroy(){recognizer?.destroy();tts.shutdown();scope.cancel();super.onDestroy()}
}

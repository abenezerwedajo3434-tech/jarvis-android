# JARVIS — Proper Android Build

This is a native Android/Kotlin JARVIS foundation intended to be built into an APK.

## What is included
- Futuristic JARVIS interface
- Text chat
- Android speech recognition microphone button
- Text-to-speech JARVIS voice
- Persistent local memory (`remember ...` / `what do you remember`)
- Safe Android intents for opening websites
- Configurable AI backend URL
- Foreground microphone service shell for voice mode
- Android 14+ foreground-service microphone declarations

Android requires microphone foreground services to declare the appropriate service type and permissions on newer targets. Continuous `SpeechRecognizer` listening is intentionally not used as a fake always-on wake word because Android documents that `SpeechRecognizer` is not intended for continuous recognition. citeturn0search2turn0search7

## Important
This project does NOT embed an OpenAI API key. Put the AI API key on your server and expose a `/jarvis` endpoint that accepts JSON `{ "message": "...", "memory": "..." }` and returns `{ "reply": "..." }`.

## Build
Open this folder in Android Studio, let Gradle sync, then Build > Build APK(s).

## Backend
Your backend can call the OpenAI Responses API. Keep secrets on the server, not in the APK.

## Wake word
The WAKE button starts the foreground voice-mode service, but a genuine always-on "Hey JARVIS" detector requires a dedicated wake-word engine. Android's standard SpeechRecognizer is not designed for continuous recognition. citeturn0search2

## Phone actions
The architecture is ready for adding explicit, permission-gated actions such as opening apps, placing calls, sending messages, alarms, and device settings. These should be implemented with Android's official intents/APIs and clear user permissions.
